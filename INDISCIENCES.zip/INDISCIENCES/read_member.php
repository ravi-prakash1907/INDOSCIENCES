<?php
	$name  = $_POST['name'];
	$pass  = $_POST['pass']; 
	$find = ":".$name.":".$pass;
	$filename = "members.txt";
	
	//opening the file to read
	$file_read = fopen( $filename, 'r' );
	if( $file_read == false ) 
	{ 
		echo ( "Error in opening new file." ); 
		exit(); 
	}
	$flag = 5;
	//checking that user has registered earlier or not
	while( ($line = fgets($file_read) ) !== false )
	{
		if(@strpos($line, $find) !== false)
		{
			$flag = 0;
			break;
		}
		else
		if((@strpos($line, $name) !== false) && (@strpos($line, $pass) === false))
		{
			$flag = 2;
			break;
		}
		if((@strpos($line, $pass) !== false) && (@strpos($line, $name) === false))
		{
			$flag = 3;
			break;
		}
	}
	fclose( $file_read );
	
	if($name == "" || $pass == "")
		$flag = 1;
	
	switch ($flag)
	{
		case 0:
			echo sleep(1);
			$ch = curl_init("http://localhost/site7/admin__index.php");
			curl_exec($ch);
			echo "<script type='text/javascript'>
				alert('Signed In, successfuly!');
			</script>";
			exit();
			
		case 1:
			$ch = curl_init("http://localhost/site7/login.php");
			curl_exec($ch);
			echo "<script type='text/javascript'>
				alert('Oops! It seems that any field is left blank.');
			</script>";
			exit();
		
		case 2:
			$ch = curl_init("http://localhost/site7/login.php");
			curl_exec($ch);
			echo "<script type='text/javascript'>
				alert('Incurrect Passwod! Try again.');
			</script>";
			exit();
		
		case 3:
			$ch = curl_init("http://localhost/site7/login.php");
			curl_exec($ch);
			echo "<script type='text/javascript'>
				alert('Incurrect Username! Try again.');
			</script>";
			exit();
			
		default: 
			$ch = curl_init("http://localhost/site7/login.php");
			curl_exec($ch);
			echo "<script type='text/javascript'>
				alert('Please register before logging in!!');
			</script>";
			exit();
	}
?>
	