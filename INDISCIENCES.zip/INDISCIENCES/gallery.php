<!DOCTYPE html>
<html lang="en">
  <head>
<link rel="icon" href="logo_IndoSciences.ico">
    <meta charset="utf-8">
    <meta http-equiv="refresh" content="300">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">  
    <title>IndoSciences - Gallery</title>
    <meta name="description" content="">
    <meta name="author" content="indosciences">
    <!-- 
    IndoSciences Template
    -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,700' rel='stylesheet' type='text/css'>
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/indosciences-style.css" rel="stylesheet">
	
	<link rel="stylesheet" href="css/bootstrap.min2.css">                                      <!-- Bootstrap style -->
    <link rel="stylesheet" href="css/magnific-popup.css">     
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

  </head>
  <body>  
    <!-- Left column -->
    <div class="indosciences-flex-row">
      <div class="indosciences-sidebar">
        <header class="indosciences-site-header">
          <div class="square"></div>
          <h1>IndoSciences</h1>
        </header>
        <div class="profile-photo-container">
          <img src="images/profile-photo.jpg" alt="Profile Photo" class="img-responsive">  
          <div class="profile-photo-overlay"></div>
        </div>      
        <!-- Search box -->
        <form class="indosciences-search-form" role="search">
          <div class="input-group">
              <button type="submit" class="fa fa-search"></button>
              <input type="text" class="form-control" placeholder="Search" name="srch-term" id="srch-term">           
          </div>
        </form>
        <div class="mobile-menu-icon">
            <i class="fa fa-bars"></i>
          </div>
        <nav class="indosciences-left-nav">          
          <ul>
            <li><a href="index.php"><i class="fa fa-home fa-fw"></i>Home</a></li>
            <li><a href="history.php"><i class="fa fa-bar-chart fa-fw"></i>History of Sciences</a></li>
			<li><a href="vedic_research.php"><i class="fa fa-sliders fa-fw"></i>Vedic Research</a></li>
            <li><a href="visitor_work.php"><i class="fa fa-database fa-fw"></i>Submit your Work</a></li>
            <li><a href="gallery.php" class="active"><i class="fa fa-sliders fa-fw"></i>Gallery</a></li>
            <li><a href="sign_up.php"><i class="fa fa-eject fa-fw"></i>Register</a></li>
          </ul>  
        </nav>
		
		<nav>
			<ul>
				<li class="follow"><i></i>Follow Us<br><hr></li>
				<li><a href="#"><img src="images/twitter.png" /></a></li>
			</ul>
		</nav>
		
      </div>
      <!-- Main content --> 
      <div class="indosciences-content col-1 light-gray-bg">
        <div class="indosciences-top-nav-container">
          <div class="row">
            <nav class="indosciences-top-nav col-lg-12 col-md-12">
              <ul class="text-uppercase">
                <li><a href="index.php">Home</a></li>
                <li><a href="branches.php">Branches</a></li>
				<li><a href="library.php">Library</a></li>
                <li><a href="login.php">Sign in</a></li>
              </ul>  
            </nav>
          </div>
        </div>
        <div class="indosciences-content-container">
          <div class="indosciences-content-widget white-bg">
            <h2 class="margin-bottom-10">The <i>Gallery</i></h2>
            <p>The memories of ancient India...</p>
            <div class="panel panel-default no-border">
              <div class="panel-heading border-radius-10">
                <h2 class="intro">Collection</h2>
              </div>
              <div class="panel-body">
                <div class="indosciences-flex-row flex-content-row margin-bottom-30">
                  <div class="col-1">
                    <div id="gauge_div" class="welcome">
					
						<!--	CONTENT WILL GO HERE	-->
						
							<section id="secondgallery" class="tm-section">
                                
                                <div class="tm-gallery-container tm-gallery-2">
                                    <div class="tm-img-container tm-img-container-2">
                                        <a href="images/121.png"><img src="images/121.png" alt="Image" class="img-fluid tm-img-tn"></a>    
                                    </div>
                                    <div class="tm-img-container tm-img-container-2">
                                        <a href="images/122.png"><img src="images/122.png" alt="Image" class="img-fluid tm-img-tn"></a>    
                                    </div>
                                    <div class="tm-img-container tm-img-container-2">
                                        <a href="images/123.png"><img src="images/123.png" alt="Image" class="img-fluid tm-img-tn"></a>    
                                    </div>                                    
                                </div>
                            </section>
					
					</div>
                    <h3 class="text-center margin-bottom-5">Computer Resources</h3>
                    <p class="text-center">Curabitur</p>              
                  </div>              
                </div>     
              </div>
            </div>         
            <div class="panel panel-default no-border">
              <div class="panel-heading border-radius-10">
                <h2 class="intro">Timeline</h2>
              </div>
              <div class="panel-body">
                <div class="indosciences-flex-row flex-content-row">
                  <div class="col-1">
                    <div id="timeline_div" class="introduction">
					
						<!--	CONTENT WILL GO HERE	-->
					
					</div>
                    <h3 class="text-center margin-bottom-5">Conference Schedule</h3>
                    <p class="text-center">Lorem Ipsum</p>                
                  </div>              
                </div>
              </div> 
            </div>
            <div class="panel panel-default no-border">
              <div class="panel-heading border-radius-10">
                <h2 class="intro">Area Chart</h2>
              </div>
              <div class="panel-body">
                <div class="indosciences-flex-row flex-content-row">
                  <div class="col-1">
                    <div class="introduction">
					
						<!--	CONTENT WILL GO HERE	-->
					
					</div>
                    <h3 class="text-center margin-bottom-5">Company Performance</h3>
                    <p class="text-center">Fusce mi lacus</p>                
                  </div>              
                </div>
              </div> 
            </div>
          </div>
          <footer class="text-right">
            <p>Copyright &copy; 2084 Company Name 
            | Designed by <a href="http://www.indosciences.com" target="_parent">indosciences</a></p>
          </footer>  
		  
		  
		  <script src="js/jquery-1.11.3.min.js"></script>             <!-- jQuery (https://jquery.com/download/) -->
        <script src="js/jquery.magnific-popup.min.js"></script>     <!-- Magnific pop-up (http://dimsemenov.com/plugins/magnific-popup/) -->
        <script src="js/jquery.singlePageNav.min.js"></script>      <!-- Single Page Nav (https://github.com/ChrisWojcik/single-page-nav) -->
        <script>     
       
            $(document).ready(function(){

                // Single page nav
                /*
				$('.tm-main-nav').singlePageNav({
                    'currentClass' : "active",
                    offset : 20
                });
				*/

                // Magnific pop up
                $('.tm-gallery-1').magnificPopup({
                  delegate: 'a', // child items selector, by clicking on it popup will open
                  type: 'image',
                  gallery: {enabled:true}
                  // other options
                }); 

                $('.tm-gallery-2').magnificPopup({
                  delegate: 'a', // child items selector, by clicking on it popup will open
                  type: 'image',
                  gallery: {enabled:true}
                  // other options
                }); 

                $('.tm-gallery-3').magnificPopup({
                  delegate: 'a', // child items selector, by clicking on it popup will open
                  type: 'image',
                  gallery: {enabled:true}
                  // other options
                }); 

                $('.tm-current-year').text(new Date().getFullYear());                
            });
        </script> 
		
		  
        </div>
      </div>
    </div>
  </body>
</html>