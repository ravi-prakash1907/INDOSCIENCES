<?php
	$content = $_POST['tab_saankhya'];
	$filename = "tab_saankhya.txt";
					
	$file_write = @fopen( $filename, 'w' );
	@fwrite($file_write, $content);
	@fclose( $file_write );
	$ch = "http://localhost/site7/admin__branch_saankhya.php";
	return(header( "Location:$ch" ));
?>