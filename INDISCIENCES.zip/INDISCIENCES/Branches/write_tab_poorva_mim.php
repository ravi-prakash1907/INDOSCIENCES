<?php
	$content = $_POST['tab_poorva_mim'];
	$filename = "tab_poorva_mim.txt";
					
	$file_write = @fopen( $filename, 'w' );
	@fwrite($file_write, $content);
	@fclose( $file_write );
	$ch = "http://localhost/site7/admin__branch_poorva_mimansa.php";
	return(header( "Location:$ch" ));
?>