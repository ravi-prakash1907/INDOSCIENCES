<?php

	/*	------------------	*/

	$content1 = $_POST['saankhya'];
	$content2 = $_POST['yog'];
	$content3 = $_POST['nyaya'];
	$content4 = $_POST['vaisheshik'];
	$content5 = $_POST['vedant'];
	$content6 = $_POST['poorva_mim'];

	//----------------

	$filename1 = "saankhya.txt";
					
	$file_write = @fopen( $filename1, 'w' );
	@fwrite($file_write, $content1);
	@fclose( $file_write );
	
	//-----------------

	$filename2 = "yog.txt";
					
	$file_write = @fopen( $filename2, 'w' );
	@fwrite($file_write, $content2);
	@fclose( $file_write );
	
	//-----------------
	
	$filename3 = "nyaya.txt";
					
	$file_write = @fopen( $filename3, 'w' );
	@fwrite($file_write, $content3);
	@fclose( $file_write );
	
	//-----------------
	
	$filename4 = "vaisheshik.txt";
					
	$file_write = @fopen( $filename4, 'w' );
	@fwrite($file_write, $content4);
	@fclose( $file_write );
	
	//-----------------
	
	$filename5 = "vedant.txt";
					
	$file_write = @fopen( $filename5, 'w' );
	@fwrite($file_write, $content5);
	@fclose( $file_write );
	
	//-----------------
	
	$filename6 = "poorva_mim.txt";
					
	$file_write = @fopen( $filename6, 'w' );
	@fwrite($file_write, $content6);
	@fclose( $file_write );
	
	
	/*	--------------------------	*/
	$ch = "http://localhost/site7/admin__branches.php";
	return(header( "Location:$ch" ));
	
?>