<?php
	$content = $_POST['tab_vaisheshik'];
	$filename = "tab_vaisheshik.txt";
					
	$file_write = @fopen( $filename, 'w' );
	@fwrite($file_write, $content);
	@fclose( $file_write );
	$ch = "http://localhost/site7/admin__branch_vaisheshik.php";
	return(header( "Location:$ch" ));
?>