<?php
	$content = $_POST['poorva_mim'];
	$filename = "poorva_mim.txt";
					
	$file_write = @fopen( $filename, 'w' );
	@fwrite($file_write, $content);
	@fclose( $file_write );
	$ch = "http://localhost/site7/admin__branches.php";
	return(header( "Location:$ch" ));
?>