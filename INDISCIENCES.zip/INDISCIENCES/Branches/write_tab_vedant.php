<?php
	$content = $_POST['tab_vedant'];
	$filename = "tab_vedant.txt";
					
	$file_write = @fopen( $filename, 'w' );
	@fwrite($file_write, $content);
	@fclose( $file_write );
	$ch = "http://localhost/site7/admin__branch_uttar_mimansa.php";
	return(header( "Location:$ch" ));
?>