<?php
	$content = $_POST['saankhya'];
	$filename = "saankhya.txt";
					
	$file_write = @fopen( $filename, 'w' );
	@fwrite($file_write, $content);
	@fclose( $file_write );
	$ch = "http://localhost/site7/admin__branches.php";
	return(header( "Location:$ch" ));
?>