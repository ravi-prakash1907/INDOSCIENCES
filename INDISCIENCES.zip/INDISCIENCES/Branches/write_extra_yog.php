<?php
	$content = $_POST['about'];
	$filename = "extra_yog.txt";
					
	$file_write = @fopen( $filename, 'w' );
	@fwrite($file_write, $content);
	@fclose( $file_write );
	$ch = "http://localhost/site7/admin__branch_yog.php";
	return(header( "Location:$ch" ));
?>