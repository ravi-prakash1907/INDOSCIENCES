<?php
	$content = $_POST['about'];
	$filename = "contect_details.txt";
					
	$file_write = @fopen( $filename, 'w' );
	@fwrite($file_write, $content);
	@fclose( $file_write );
	$ch = "http://localhost/site7/admin__visitor_work.php";
	return(header( "Location:$ch" ));
?>