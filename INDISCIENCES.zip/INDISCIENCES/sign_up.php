<!DOCTYPE html>
<html lang="en">
	<head>
<link rel="icon" href="logo_IndoSciences.ico">
		<meta charset="utf-8">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta name="viewport" content="width=device-width, initial-scale=1">
	    <title>IndoSciences - Sign Up</title>
        <meta name="description" content="">
        <meta name="author" content="indosciences">
        <!--
        IndoSciences Template
        http://www.indosciences.com/preview/indosciences_455_visual_admin
        -->
	    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,700' rel='stylesheet' type='text/css'>
	    <link href="css/font-awesome.min.css" rel="stylesheet">
	    <link href="css/bootstrap.min.css" rel="stylesheet">
	    <link href="css/indosciences-style.css" rel="stylesheet">
	    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	    <!--[if lt IE 9]>
	      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	    <![endif]-->
	</head>
	<body class="light-gray-bg">
		<div class="indosciences-content-widget indosciences-login-widget white-bg">
			<header class="text-center">
	          <div class="square"></div>
	          <h1>IndoSciences</h1>
	        </header>
	        <form action="write_member.php" method="post" class="indosciences-login-form">
				<div class="form-group">
	        		<div class="input-group">
		              	<input type="text" name="myfirstname" class="form-control" placeholder="First Name" required="">
							<div class="input-group-addon" id="name"></div>
		              	<input type="text" name="mylastname" class="form-control" placeholder="Last Name" required="">
		          	</div>
	        	</div>
	        	<div class="form-group">
	        		<div class="input-group">
		              	<input type="text" name="myusername" id="username" class="form-control" placeholder="Username" required="">
		          	</div>
	        	</div>
				<div class="form-group">
	        		<div class="input-group">
		        		<div class="input-group-addon"><i class="fa fa-user fa-fw"></i></div>
		              	<input type="email" name="myemailid" class="form-control" placeholder="E-mail Address" required="">
		          	</div>
	        	</div>
				<div class="form-group">
	        		<div class="input-group">
		        		<div class="input-group-addon"><i class="fa fa-key fa-fw"></i></div>
		              	<input type="password" name="myrealpass" class="form-control" placeholder="Password" required="">
		          	</div>
	        	</div>
	        	<div class="form-group">
	        		<div class="input-group">
		        		<div class="input-group-addon"><i class="fa fa-key fa-fw"></i></div>
		              	<input type="password" name="myconfirmedpass" class="form-control" placeholder="Confirm Password" required="">
		          	</div>
	        	</div>
	          	<div class="form-group">
				    <div class="checkbox squaredTwo">
				        <input type="checkbox" id="c1" name="cc" />
						<label for="c1"><span></span>I agree!</label>
						<p style="padding: 6%">
						  <font color="#F79292">
							It's a registration panal for new administrater of this site. Registering here without the wish of the owner of the 
							<b><i>IndoSciences</i></b> can be treated under <b>Syber Crime</b>.<br />
							By clicking <b>'I agree!'</b>, you insure that- you have permission to 
							<a href="visitor_work.php#contribute"><abbr title="Get permission to Register!!">contribute</abbr></a> in managing this site.
						  </font>
						</p>
				    </div>
				</div>
				<div class="form-group">
					<button type="submit" class="indosciences-blue-button width-100">Register Me</button>
				</div>
	        </form>
		</div>
		<div class="indosciences-content-widget indosciences-login-widget indosciences-register-widget white-bg">
			<p>Already registered? <strong><a href="login.php" class="blue-text">Login!</a></strong></p>
		</div>
	</body>
</html>