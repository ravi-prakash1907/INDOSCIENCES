<!DOCTYPE html>
<html lang="en">
  <head>
<link rel="icon" href="logo_IndoSciences.ico">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">  
    <title>Admin - Vedant</title>
    <meta name="description" content="">
    <meta name="author" content="indosciences">
    <!-- 
    IndoSciences Template
    -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,700' rel='stylesheet' type='text/css'>
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/indosciences-style.css" rel="stylesheet">
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

  </head>
  <body>  
    <!-- Left column -->
    <div class="indosciences-flex-row">
      <div class="indosciences-sidebar">
        <header class="indosciences-site-header">
          <div class="square"></div>
          <h1>IndoSciences</h1>
        </header>
        <div class="profile-photo-container">
          <img src="images/profile-photo.jpg" alt="Profile Photo" class="img-responsive">  
          <div class="profile-photo-overlay"></div>
        </div>      
        <!-- Search box -->
        <form class="indosciences-search-form" role="search">
          <div class="input-group">
              <button type="submit" class="fa fa-search"></button>
              <input type="text" class="form-control" placeholder="Search" name="srch-term" id="srch-term">           
          </div>
        </form>
        <div class="mobile-menu-icon">
            <i class="fa fa-bars"></i>
        </div>
        <nav class="indosciences-left-nav">          
          <ul>
            <li><a href="admin__index.php"><i class="fa fa-home fa-fw"></i>Home</a></li>
            <li><a href="admin__branch_saankhya.php"><i class="fa fa-sliders fa-fw"></i>Saankhya   (साँख्य)</a></li>
            <li><a href="admin__branch_yog.php"><i class="fa fa-sliders fa-fw"></i>Yog   (योग)</a></li>
            <li><a href="admin__branch_nyaya.php"><i class="fa fa-sliders fa-fw"></i>Nyaya   (न्याय)</a></li>
            <li><a href="admin__branch_vaisheshik.php"><i class="fa fa-sliders fa-fw"></i>Vaisheshik   (वैशेषिक)</a></li>
            <li><a href="admin__branch_uttar_mimansa.php" class="active"><i class="fa fa-sliders fa-fw"></i>Vedanta   (वेदांत)</a></li>
            <li><a href="admin__branch_poorva_mimansa.php"><i class="fa fa-sliders fa-fw"></i>Poorva-Mimansa   (पूर्वमीमांसा)</a></li>
          </ul>  
        </nav>
      
		<nav>
			<ul>
				<li class="follow"><i></i>Follow Us<br><hr></li>
				<li><a href="#"><img src="images/twitter.png" /></a></li>
			</ul>
		</nav>
		
      </div>
      <!-- Main content --> 
      <div class="indosciences-content col-1 light-gray-bg">
        <div class="indosciences-top-nav-container">
          <div class="row">
            <nav class="indosciences-top-nav col-lg-12 col-md-12">
              <ul class="text-uppercase">
                <li><a href="admin__index.php">Home</a></li>
                <li><a href="admin__branches.php">Branches</a></li>
				<li><a href="admin__library.php">Library</a></li>
            <li><a href="index.php" onClick="alert('Successfully logged out!');">Sign Out</a></li>
              </ul>  
            </nav> 
          </div>
        </div>
        <div class="indosciences-content-container">
          <div class="indosciences-content-widget white-bg">
            <h2 class="margin-bottom-10">Uttar-Mimansa or Vedant</h2>
            <div class="panel panel-default no-border">
              <div class="panel-heading border-radius-10">
                <h2 class="intro">(उत्तर-मीमांसा अथवा वेदांत)</h2>
              </div>
              <div class="panel-body">
                <div class="indosciences-flex-row flex-content-row margin-bottom-30">
                  <div class="col-1">
                    <form action="branches/write_tab_vedant.php" method="post">
						<textarea class="form-control" rows="20" name="tab_vedant">
							<?php
								$filename = "branches/tab_vedant.txt";
							
								$file_read = @fopen( $filename, 'r' );
								if( $file_read == false ) 
								{ 
									echo ( "Nothing is available right now." );
								}
								else
								{
									$filesize = @filesize( $filename ); 
									$about = @fread($file_read, $filesize);
									echo ("$about");
								}
								@fclose( $file_read );
							?>
						</textarea>
						<br />
						<input type="submit" class="indosciences-blue-button" value="update" />
					</form>
                    <h3 class="text-center margin-bottom-5">Computer Resources</h3>
                    <p class="text-center">Curabitur</p>              
                  </div>              
                </div>     
              </div>
            </div>         
            <div class="panel panel-default no-border">
              <div class="panel-heading border-radius-10">
                <h2 class="intro">Timeline</h2>
              </div>
              <div class="panel-body">
                <div class="indosciences-flex-row flex-content-row">
                  <div class="col-1">
                    <div id="timeline_div" class="introduction">
					
						<!--	CONTENT WILL GO HERE	-->
					
					</div>
                    <h3 class="text-center margin-bottom-5">Conference Schedule</h3>
                    <p class="text-center">Lorem Ipsum</p>                
                  </div>              
                </div>
              </div> 
            </div>
            <div class="panel panel-default no-border">
              <div class="panel-heading border-radius-10">
                <h2 class="intro">Area Chart</h2>
              </div>
              <div class="panel-body">
                <div class="indosciences-flex-row flex-content-row">
                  <div class="col-1">
                    <form action="Branches/write_extra_vedant.php" method="post">
						<textarea class="form-control" rows="20" name="about">
							<?php
								$filename = "branches/extra_vedant.txt";
							
								$file_read = @fopen( $filename, 'r' );
								if( $file_read == false ) 
								{ 
									echo ( "Nothing is available right now." );
								}
								else
								{
									$filesize = @filesize( $filename ); 
									$about = @fread($file_read, $filesize);
									echo ("$about");
								}
								@fclose( $file_read );
							?>
						</textarea>
						<br />
						<input type="submit" class="indosciences-blue-button" value="update" />
					</form>
                    <h3 class="text-center margin-bottom-5">Company Performance</h3>
                    <p class="text-center">Fusce mi lacus</p>                
                  </div>              
                </div>
              </div> 
            </div>
          </div>
          <footer class="text-right">
            <p>Copyright &copy; 2084 Company Name 
            | Designed by <a href="http://www.indosciences.com" target="_parent">indosciences</a></p>
          </footer>  
		  
		  
        </div>
      </div>
    </div>
  </body>
</html>