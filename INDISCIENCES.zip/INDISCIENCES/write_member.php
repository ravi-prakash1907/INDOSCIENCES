<?php
	$fsname = $_POST['myfirstname'];
	$lsname = $_POST['mylastname'];
	$usname = $_POST['myusername'];
	$esmailid = $_POST['myemailid'];
	$mspass = $_POST['myrealpass'];
	$cspass = $_POST['myconfirmedpass'];
	$agree = @$_POST['cc'];
	
	
	//checking agreement
		if($agree == false)
		{
			$ch = curl_init("http://localhost/site7/sign_up.php");
			curl_exec($ch);
		
			echo "<script type='text/javascript'>
					alert('You must have to tick \'I agree!\' before proceeding');
				  </script>";
			exit();
		}

	$filename = "members.txt"; 
	
	//opening the file to read
	$file_read = fopen( $filename, "r" );
	if( $file_read == false ) 
	{ 
		echo ( "Error in opening new file" ); 
		exit(); 
	}
	
	//checking that user has registered earlier or not
	while( ($line = fgets($file_read) ) !== false )
	{
		$userData = explode(':',$line);
		$flag = 0;
		if( @$userData[2] != $usname )
			if( @$userData[3] != $esmailid )
			{
				$flag = 1;
				continue;
			}
		fclose( $file_read ); 
		break;
	}
	if ($flag == 0)
		goto match1;	//in case if user is already registered

	/*	SIGN UP PROCESS STSRTS HERE	*/
	
	//opening file to write (read too) data of new user for registration
	$file_write = fopen( $filename, "a+" ); 
	if( $file_write == false ) 
	{ 
		echo ( "Error in opening new file" ); 
		exit(); 
	}
	
	//checking if there is any accidental mistake in entering password
	if($mspass == $cspass)
	{
		fwrite( $file_write, "$fsname:$lsname:$usname:$esmailid:$mspass\n" );
		fwrite( $file_write, "$fsname:$lsname:$esmailid:$usname:$mspass\n\n" );
		fclose( $file_write ); 
		$ch = curl_init("http://localhost/site7/sign_up.php");
		curl_exec($ch);
		
		//message for successful regestration
		echo "<script type='text/javascript'>
			alert('$fsname! You are successfully registered!');
			</script>";
		exit();
	}
	
	/* SIGN UP PROCESS ENDS HERE */
	
	else
		goto match2; //in case if password is not cofirmed
	
	/* message for already registered users */
	match1: 
	{
		$ch = curl_init("http://localhost/site7/sign_up.php");
		curl_exec($ch);
		
	echo "<script type='text/javascript'>
		alert('You are already registered!');
	</script>";
	exit();
	}
	
	/* message for not confirmed password */
	match2: 
	{
		$ch = curl_init("http://localhost/site7/sign_up.php");
		curl_exec($ch);
		
	echo "<script type='text/javascript'>
		alert('Confirm password again!');
	</script>";
	exit();
	}
?>
	