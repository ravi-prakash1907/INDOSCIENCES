<?php

$name = strip_tags(htmlspecialchars($_POST['name']));
$email_address = strip_tags(htmlspecialchars($_POST['email']));
$phone = strip_tags(htmlspecialchars($_POST['phone']));
$message = strip_tags(htmlspecialchars($_POST['message']));
	
// Create the email and send the message
$to = '1907prakash.ravi@gmail.com';
$email_subject = "Website Contact Form:  $name";
$email_body = "You have received a new message from your website contact form.\n\n"."Here are the details:\n\nName: $name\n\nEmail: $email_address\n\nPhone: $phone\n\nMessage:\n$message";
$headers = "From: 1907prakash.ravi@gmail"; // This is the email address the generated message will be from. Use something like noreply@yourdomain.com.
$headers .= "Reply-To: $email_address";	

if (mail($to,$email_subject,$email_body,$headers))
{
	$ch = curl_init("http://localhost/site7/visitor_work.php");
	curl_exec($ch);
	
   echo "<script type='text/javascript'>
					alert('Mail sent SUCCESSFULLY!!');
		</script>";
} 
else 
{
	$ch = curl_init("http://localhost/site7/visitor_work.php");
	curl_exec($ch);
	
   echo "<script type='text/javascript'>
					alert('ERROR in sending mail!!');
		</script>";
}

?>