<?php
	$content = $_POST['about'];
	$filename = "about.txt";
					
	$file_write = @fopen( $filename, 'w' );
	@fwrite($file_write, $content);
	@fclose( $file_write );
	$ch = "http://localhost/site7/admin__index.php";
	return(header( "Location:$ch" ));
?>