<?php
	$content = $_POST['about'];
	$filename = "poorva_mim.txt";
					
	$file_write = @fopen( $filename, 'w' );
	@fwrite($file_write, $content);
	@fclose( $file_write );
	$ch = "http://localhost/site7/admin__library.php";
	return(header( "Location:$ch" ));
?>